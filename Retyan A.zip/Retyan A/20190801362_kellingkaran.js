var nilai = require('readline-sync');

var pi = 3.14
var r = parseInt(nilai.question("Masukan Nilai r : "));

var keliling = 2 * pi * r;

console.log(keliling);
